/*
 * plain.cpp -- Scalar partition mapping kernel.
 *
 * Compiled twice from the same source:
 *   - baseline: -fno-tree-vectorize (auto-vectorization disabled)
 *   - autovec:  -O3 -march=native   (auto-vectorization enabled)
 *
 * Hash: h(k) = ((k_lo ^ k_hi) * A32) >> shift32
 *
 * The loop is written to satisfy GCC auto-vectorization requirements:
 * unit stride, no inter-iteration dependencies, no function calls,
 * __restrict__ to exclude aliasing, trip count known at loop entry.
 */

#include "common.hpp"

/**
 * Kernel fn:
 * calculate the partition id for each key (N in total)
 * keys & part_ids must be created using aligned mem
 */
void partition_map(const spm_key_t *__restrict__ keys,
                   part_t *__restrict__ part_ids,
                   size_t N,
                   unsigned shift)
{
    for (size_t i = 0; i < N; i++)
    {
        uint32_t k_lo = static_cast<uint32_t>(keys[i]);
        uint32_t k_hi = static_cast<uint32_t>(keys[i] >> 32);
        uint32_t mixed = k_lo ^ k_hi;
        part_ids[i] = (mixed * HASH_A32) >> shift;
    }
}

int main(int argc, char *argv[])
{
    if (argc < 3)
    {
        std::cerr << "Usage: " << argv[0] << " <N> <P> [seed] [key_space] [reps]\n";
        return 1;
    }

    const size_t N = std::stoull(argv[1]);
    const uint32_t P = std::stoul(argv[2]);
    const uint64_t seed = (argc > 3) ? std::stoull(argv[3]) : 42;
    const uint64_t key_space = (argc > 4) ? std::stoull(argv[4]) : 0;
    const int reps = (argc > 5) ? std::stoi(argv[5]) : 11;

    if (P == 0 || (P & (P - 1)) != 0)
    {
        std::cerr << "P must be a power of 2 (got " << P << ")\n";
        return 1;
    }
    const unsigned shift = compute_shift(P);

    spm_key_t *keys = alloc_aligned<spm_key_t>(N);
    part_t *part_ids = alloc_aligned<part_t>(N);
    KeyGenerator::generate(keys, N, seed, key_space);

    //warmup: fill caches and TLB
    partition_map(keys, part_ids, N, shift);

    std::vector<double> times;
    times.reserve(reps);
    for (int r = 0; r < reps; r++)
    {
        auto t0 = std::chrono::high_resolution_clock::now();
        partition_map(keys, part_ids, N, shift);
        auto t1 = std::chrono::high_resolution_clock::now();
        times.push_back(std::chrono::duration<double, std::milli>(t1 - t0).count());
    }

    uint64_t cksum = compute_checksum(part_ids, N);
    auto result = benchmark(times, N);

#ifdef AUTOVEC_ENABLED
    print_result("plain (autovec)", result);
#else
    print_result("plain (no-vec)", result);
#endif

    std::cout << "  checksum=0x" << std::hex << cksum << std::dec << "\n";
    std::cout << "  P=" << P << " shift=" << shift
              << " seed=" << seed << " key_space=" << key_space << "\n";

    // element-wise output for small N (manual verification)
    if (N <= 32)
    {
        std::cout << "\n  Element-wise output:\n";
        for (size_t i = 0; i < N; i++)
            std::cout << "    keys[" << i << "]=" << keys[i]
                      << " -> " << part_ids[i] << "\n";
    }

    // partition distribution check
    if (P <= 1024)
    {
        std::vector<uint64_t> counts(P, 0);
        for (size_t i = 0; i < N; i++)
            counts[part_ids[i]]++;

        uint64_t mn = *std::min_element(counts.begin(), counts.end());
        uint64_t mx = *std::max_element(counts.begin(), counts.end());
        double exp = static_cast<double>(N) / P;
        std::cout << "  Distribution: min=" << mn << " max=" << mx
                  << " expected=" << std::fixed << std::setprecision(1) << exp
                  << " max/expected=" << std::setprecision(4) << (mx / exp) << "\n";
    }

    std::free(keys);
    std::free(part_ids);
    return 0;
}
