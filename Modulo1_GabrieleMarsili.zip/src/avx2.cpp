/*
 * avx2.cpp -- Partition mapping with AVX2 intrinsics.
 *
 * Processes 8 keys per iteration:
 *   1. Load 8 uint64 keys (2 x ymm registers, 4 keys each)
 *   2. XOR-fold each key to 32 bits (k_lo ^ k_hi)
 *   3. Pack the 8 folded values into a single ymm register
 *   4. Fibonacci multiply (_mm256_mullo_epi32 = vpmulld, native)
 *   5. Right-shift to extract partition id
 *   6. Store 8 x uint32 results
 *
 * Scalar tail handles the remaining N%8 keys.
 * Correctness is verified against a scalar reference before benchmarking.
 */

#include "common.hpp"
#include <immintrin.h>

/**
 * AVX2 kernel: processes 8 keys per iteration using 
 * 2 ymm loads + XOR fold + pack + vpmulld + shift + store
 */
void partition_map_avx2(const spm_key_t *__restrict__ keys,
                        part_t *__restrict__ part_ids,
                        size_t N,
                        unsigned shift)
{
    //init hash constant broadcast
    const __m256i va32 = _mm256_set1_epi32(static_cast<int32_t>(HASH_A32));
    // shuffle indices to extract low 32 bits from each 64-bit lane
    const __m256i shuf = _mm256_setr_epi32(0, 2, 4, 6, 1, 3, 5, 7);
    const size_t simd_end = N - (N % 8);

    for (size_t i = 0; i < simd_end; i += 8)
    {
        // load 4+4 keys (each register holds 4 uint64)
        __m256i vk0 = _mm256_load_si256(reinterpret_cast<const __m256i *>(&keys[i]));
        __m256i vk1 = _mm256_load_si256(reinterpret_cast<const __m256i *>(&keys[i + 4]));

        // XOR fold: shift right 32 to get k_hi, XOR with k_lo
        // result sits in the low 32 bits of each 64-bit lane
        __m256i hi0 = _mm256_srli_epi64(vk0, 32);
        __m256i hi1 = _mm256_srli_epi64(vk1, 32);
        __m256i x0 = _mm256_xor_si256(vk0, hi0);
        __m256i x1 = _mm256_xor_si256(vk1, hi1);

        // pack 4+4 low-32 values into one register of 8 x uint32:
        // shuf=[0,2,4,6,1,3,5,7] picks the low-32 dword from each 64-bit lane
        // permute2x128 with 0x20 takes lower half of p0 and lower half of p1
        __m256i p0 = _mm256_permutevar8x32_epi32(x0, shuf);
        __m256i p1 = _mm256_permutevar8x32_epi32(x1, shuf);
        __m256i mixed = _mm256_permute2x128_si256(p0, p1, 0x20);

        // Fibonacci mul32 + shift -> partition id
        __m256i prod = _mm256_mullo_epi32(mixed, va32);
        __m256i h = _mm256_srli_epi32(prod, shift);

        _mm256_storeu_si256(reinterpret_cast<__m256i *>(&part_ids[i]), h);
    }

    // scalar tail
    for (size_t i = simd_end; i < N; i++)
        part_ids[i] = hash_key(keys[i], shift);
}

// scalar reference with auto-vectorization explicitly disabled
#pragma GCC push_options
#pragma GCC optimize ("no-tree-vectorize")
static void partition_map_scalar(const spm_key_t *__restrict__ keys,
                                 part_t *__restrict__ part_ids,
                                 size_t N,
                                 unsigned shift)
{
    for (size_t i = 0; i < N; i++)
        part_ids[i] = hash_key(keys[i], shift);
}
#pragma GCC pop_options

int main(int argc, char *argv[])
{
    if (argc < 3)
    {
        std::cerr << "Usage: " << argv[0] << " <N> <P> [seed] [key_space] [reps]\n";
        return 1;
    }

    const size_t N = std::stoull(argv[1]);
    const uint32_t P = std::stoul(argv[2]);
    const uint64_t seed = (argc > 3) ? std::stoull(argv[3]) : 42;
    const uint64_t key_space = (argc > 4) ? std::stoull(argv[4]) : 0;
    const int reps = (argc > 5) ? std::stoi(argv[5]) : 11;

    if (P == 0 || (P & (P - 1)) != 0)
    {
        std::cerr << "P must be a power of 2 (got " << P << ")\n";
        return 1;
    }
    const unsigned shift = compute_shift(P);

    spm_key_t *keys = alloc_aligned<spm_key_t>(N);
    part_t *part_avx2 = alloc_aligned<part_t>(N);
    part_t *part_scalar = alloc_aligned<part_t>(N);

    KeyGenerator::generate(keys, N, seed, key_space);

    // --- correctness check ---
    partition_map_scalar(keys, part_scalar, N, shift);
    partition_map_avx2(keys, part_avx2, N, shift);

    uint64_t cksum_scalar = compute_checksum(part_scalar, N);
    uint64_t cksum_avx2 = compute_checksum(part_avx2, N);

    if (cksum_scalar != cksum_avx2)
    {
        for (size_t i = 0; i < N; i++)
        {
            if (part_scalar[i] != part_avx2[i])
            {
                std::cerr << "MISMATCH i=" << i << " key=" << keys[i]
                          << " scalar=" << part_scalar[i]
                          << " avx2=" << part_avx2[i] << "\n";
                break;
            }
        }
        std::cerr << "AVX2 output differs from scalar!\n";
        std::free(keys);
        std::free(part_avx2);
        std::free(part_scalar);
        return 1;
    }
    std::cout << "Correctness: OK (checksum=0x"
              << std::hex << cksum_avx2 << std::dec << ")\n";

    if (N <= 32)
    {
        for (size_t i = 0; i < N; i++)
            std::cout << "  keys[" << i << "]=" << keys[i]
                      << "  scalar=" << part_scalar[i]
                      << "  avx2=" << part_avx2[i]
                      << (part_scalar[i] == part_avx2[i] ? "  OK" : "  FAIL") << "\n";
    }

    // --- benchmark ---
    partition_map_avx2(keys, part_avx2, N, shift); // warmup

    std::vector<double> t_avx2, t_scalar;
    t_avx2.reserve(reps);
    t_scalar.reserve(reps);

    for (int r = 0; r < reps; r++)
    {
        auto t0 = std::chrono::high_resolution_clock::now();
        partition_map_avx2(keys, part_avx2, N, shift);
        auto t1 = std::chrono::high_resolution_clock::now();
        t_avx2.push_back(std::chrono::duration<double, std::milli>(t1 - t0).count());
    }

    partition_map_scalar(keys, part_scalar, N, shift); // warmup
    for (int r = 0; r < reps; r++)
    {
        auto t0 = std::chrono::high_resolution_clock::now();
        partition_map_scalar(keys, part_scalar, N, shift);
        auto t1 = std::chrono::high_resolution_clock::now();
        t_scalar.push_back(std::chrono::duration<double, std::milli>(t1 - t0).count());
    }

    auto res_avx2 = benchmark(t_avx2, N);
    auto res_scalar = benchmark(t_scalar, N);

    print_result("scalar (reference)", res_scalar);
    print_result("AVX2 (intrinsics)", res_avx2);
    std::cout << "  Speedup AVX2 vs scalar: " << std::fixed << std::setprecision(2)
              << (res_scalar.median_ms / res_avx2.median_ms) << "x\n";
    std::cout << "  P=" << P << " shift=" << shift
              << " seed=" << seed << " key_space=" << key_space << "\n";

    if (P <= 1024)
    {
        std::vector<uint64_t> counts(P, 0);
        for (size_t i = 0; i < N; i++)
            counts[part_avx2[i]]++;
        uint64_t mn = *std::min_element(counts.begin(), counts.end());
        uint64_t mx = *std::max_element(counts.begin(), counts.end());
        double exp = static_cast<double>(N) / P;
        std::cout << "  Distribution: min=" << mn << " max=" << mx
                  << " expected=" << std::fixed << std::setprecision(1) << exp
                  << " max/expected=" << std::setprecision(4) << (mx / exp) << "\n";
    }

    std::free(keys);
    std::free(part_avx2);
    std::free(part_scalar);
    return 0;
}
