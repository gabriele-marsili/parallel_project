#include <iostream>
#include <vector>
#include "generator.hpp"
#include "utilities_fns.hpp"
#include "common.hpp"

int test_skew_distribution() {
    std::size_t N = 10000000;
    std::uint32_t P = 128;
    std::uint64_t max_key = 100000;
    std::uint64_t seed = 42;

    double rho = 0.9;              // mixture weight on the hot pool
    std::uint32_t hot_count = 4;   // number of hot partitions

    unsigned shift = compute_shift(P);

    std::cout << "Generating skewed dataset...\n";

    auto R = generate_skewed_relation(N, seed, max_key, P, rho, hot_count);

    print_partition_histogram(R, P, shift);

    return 0;
}
