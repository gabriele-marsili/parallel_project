#include <iostream>
#include <vector>
#include "generator.hpp"
#include "utilities_fns.hpp"
#include "common.hpp"

int test_skew_distribution() {
    // Parametri del checkpoint richiesti dalla guida
    std::size_t N = 10000000;      // 10 Milioni di record
    std::uint32_t P = 128;         // 128 partizioni
    std::uint64_t max_key = 100000;
    std::uint64_t seed = 42;
    
    double rho = 0.9;              // 90% dei record...
    std::uint32_t hot_count = 4;   // ...finisce in 4 partizioni

    unsigned shift = compute_shift(P);

    std::cout << "Generazione dataset skewed in corso...\n";
    
    // Genera la relazione usando la tua nuova funzione
    auto R = generate_skewed_relation(N, seed, max_key, P, rho, hot_count);

    // Stampa il profilo
    print_partition_histogram(R, P, shift);

    return 0;
}